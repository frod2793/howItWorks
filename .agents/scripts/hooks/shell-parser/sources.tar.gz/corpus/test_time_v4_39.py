import json, subprocess, sys
binary = sys.argv[1]
baseline = sys.argv[2] if len(sys.argv) > 2 else None
cases = [
 ('time -p { cat .agents/AGENTS.md; }', 'cat .agents/AGENTS.md', False),
 ('time -p { rm -rf .agents; }', 'rm -rf .agents', False),
 ('time -p cat .agents/AGENTS.md | cat', 'cat .agents/AGENTS.md', True),
 ('time -p rm -rf .agents | cat', 'rm -rf .agents', True),
 ('time -p ! cat .agents/AGENTS.md | cat', 'cat .agents/AGENTS.md', True),
 ('time -p ! rm -rf .agents | cat', 'rm -rf .agents', True),
 ('time -p cat .agents/AGENTS.md > /tmp/native-parser-output', 'cat .agents/AGENTS.md', False),
 ('time -p rm -rf .agents > /tmp/native-parser-output', 'rm -rf .agents', False),
 ('time ! rm -rf .agents | cat', 'rm -rf .agents', True),
]
controls = [
 'time cat .agents/AGENTS.md',
 "time '-p' rm -rf .agents",
 'time \\-p rm -rf .agents',
 'time -x rm -rf .agents',
 '/usr/bin/time -p rm -rf .agents',
 'test -p /tmp/example',
 '[[ -p /tmp/example ]]',
 'echo -p',
]

def parse(which, source):
    payload = source.encode()
    syntax = subprocess.run(['/bin/bash', '-n'], input=payload, capture_output=True, timeout=5)
    assert syntax.returncode == 0, ('shell_n', source, syntax.stderr.decode())
    result = subprocess.run([which, 'bash'], input=payload, capture_output=True, timeout=5)
    assert result.returncode == 0, ('parser_rc', source, result.returncode)
    tree = json.loads(result.stdout)
    assert tree['has_error'] is False, ('parse_error', source)
    def nodes(node):
        yield node
        for child in node['children']:
            yield from nodes(child)
    flat = list(nodes(tree))
    return [(n['type'], payload[n['start_byte']:n['end_byte']].decode(), n['field']) for n in flat]

failures = []
for source, target, pipeline in cases:
    try:
        nodes = parse(binary, source)
        timed = [(kind, text, field) for kind, text, field in nodes if kind == 'time_statement']
        assert len(timed) == 1, ('time_count', timed)
        if ' > ' in source:
            # Existing grammar binds the redirect outside the timed command.
            assert timed[0][1] == source.split(' > ', 1)[0], ('time_prefix', timed)
            assert any(kind == 'redirected_statement' and text == source for kind, text, field in nodes), ('outer_redirect', nodes)
            assert any(kind == 'file_redirect' and text == '> /tmp/native-parser-output' and field == 'redirect'
                       for kind, text, field in nodes), ('redirect_target', nodes)
        else:
            assert timed[0][1] == source, ('time_span', timed)
        assert ('command', target, None) in nodes or any(kind=='command' and text==target for kind,text,field in nodes), ('target', target, nodes)
        if source.startswith('time -p'):
            assert any(kind=='time_option' and text=='-p' and field=='option' for kind,text,field in nodes), ('exact_option',nodes)
        if pipeline:
            assert any(kind=='pipeline' and text==source[len('time -p '):] for kind,text,field in nodes) or any(kind=='pipeline' and text==source[len('time '):] for kind,text,field in nodes), ('body_pipeline', nodes)
        print('PASS', source)
    except Exception as error:
        failures.append((source,repr(error)))
        print('FAIL', source, repr(error)[:180])
for source in controls:
    try:
        current = parse(binary, source)
        if baseline:
            original = parse(baseline, source)
            assert current == original, ('control_ast_changed',current,original)
        assert not any(kind == 'time_option' for kind, _, _ in current), ('unexpected_time_option',current)
        print('CONTROL_PASS', source)
    except Exception as error:
        failures.append((source,repr(error)))
        print('CONTROL_FAIL', source, repr(error)[:180])
print('RESULT',len(cases)+len(controls)-len(failures),'/',len(cases)+len(controls))
if failures: raise SystemExit(1)
