import json, subprocess, sys
binary = sys.argv[1]
cases = [
 ('time -p\\\n printf HARMLESS_MARKER', 'printf HARMLESS_MARKER', True),
 ('time -\\\np printf HARMLESS_MARKER', 'printf HARMLESS_MARKER', True),
 ('time -p\\\n rm -rf .agents', 'rm -rf .agents', False),
 ('time -\\\np rm -rf .agents', 'rm -rf .agents', False),
]
failed=[]
for source, target, safe in cases:
    raw=source.encode()
    try:
        syntax=subprocess.run(['/bin/bash','--noprofile','--norc','-n'],input=raw,capture_output=True,timeout=5)
        assert syntax.returncode==0, ('bash_n',syntax.stderr)
        if safe:
            actual=subprocess.run(['/bin/bash','--noprofile','--norc','-c',source],capture_output=True,timeout=5)
            assert actual.returncode==0 and actual.stdout==b'HARMLESS_MARKER', ('safe_actual',actual.returncode,actual.stdout)
        parsed=subprocess.run([binary,'bash'],input=raw,capture_output=True,timeout=5)
        assert parsed.returncode==0, ('parser_rc',parsed.returncode)
        tree=json.loads(parsed.stdout)
        assert not tree['has_error'], 'has_error'
        def walk(n):
            yield n
            for child in n['children']: yield from walk(child)
        flat=list(walk(tree))
        texts=lambda kind: [(raw[n['start_byte']:n['end_byte']].decode(),n['field']) for n in flat if n['type']==kind]
        assert (source,None) in texts('time_statement'), ('time_span',texts('time_statement'))
        assert (target,'body') in texts('command') or any(t==target for t,f in texts('command')), ('target',texts('command'))
        assert any(t.replace('\\\n','')=='-p' and f=='option' for t,f in texts('time_option')), ('option',texts('time_option'))
        print('PASS',repr(source))
    except Exception as error:
        failed.append((source,repr(error)))
        print('FAIL',repr(source),repr(error)[:170])
print('RESULT',len(cases)-len(failed),'/',len(cases))
if failed: raise SystemExit(1)
