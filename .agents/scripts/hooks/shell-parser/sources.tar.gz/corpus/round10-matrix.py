import json, subprocess, sys
from pathlib import Path
binary = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent / 'tsparse-test'
rows = []
for shape, safe, unsafe in [
 ('compound', '! { printf ok; }', '! { rm -rf .agents; }'),
 ('if', '! if true; then printf ok; fi', '! if true; then rm -rf .agents; fi'),
 ('while', '! while false; do printf ok; done', '! while false; do rm -rf .agents; done'),
 ('subshell', '! (printf ok)', '! (rm -rf .agents)'),
]:
 for label, source in [('safe',safe),('unsafe',unsafe)]:
  rows.append(('F4-'+shape+'-'+label,source,'negated', 'printf' if label=='safe' else 'rm'))
for kind, delimiter, prefix, suffix, expansion in [
 ('unquoted','E','','',True),
 ('quoted',"'E'",'','',False),
 ('escaped','E','\\`','\\`',False),
 ('mixed','E','$(printf x) ','',True),
]:
 for label, cmd in [('safe','printf ok'),('unsafe','rm -rf .agents')]:
  body=(prefix+cmd+suffix if kind=='escaped' else prefix+'`'+cmd+'`'+suffix)
  source='cat <<'+delimiter+'\n'+body+'\nE\n'
  rows.append(('F5-'+kind+'-'+label,source,'heredoc', cmd.split()[0] if expansion else None))
assert len(rows)==16
for dialect in ('bash','zsh'):
 for label,source,mode,expected in rows:
  result=subprocess.run([str(binary),dialect],input=source.encode(),capture_output=True,timeout=5)
  assert result.returncode==0,(dialect,label,result.stderr)
  root=json.loads(result.stdout); assert not root['has_error'],(dialect,label,'parse_error')
  nodes=[]
  def walk(n):
   nodes.append((n['type'],n['start_byte'],n['end_byte'],source.encode()[n['start_byte']:n['end_byte']].decode(),n['field']))
   for child in n['children']:walk(child)
  walk(root)
  commands=[text for kind,start,end,text,field in nodes if kind=='command_name']
  if mode=='negated':
   assert len([x for x in nodes if x[0]=='negated_command'])==1,(dialect,label)
   assert expected in commands,(dialect,label,commands)
   assert not any(x in commands for x in ('{','}','if','then','fi','while','do','done')),(dialect,label,commands)
  else:
   subs=[x for x in nodes if x[0]=='command_substitution']
   body=[x for x in nodes if x[0]=='heredoc_body']
   assert body and body[0][3]==source.split('\n')[1]+('' if dialect=='zsh' and expected else '\n'),(dialect,label,body)
   if expected:
    assert len(subs)>=1 and expected in commands,(dialect,label,subs,commands)
    for x in subs:assert source.encode()[x[1]:x[2]].decode()==x[3]
   else:assert not subs,(dialect,label,subs)
  print('PASS',dialect,label)
print('TOTAL',len(rows)*2)
