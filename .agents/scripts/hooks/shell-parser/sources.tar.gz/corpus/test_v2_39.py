import json, pathlib, subprocess, sys
binary = sys.argv[1]
cases = [
 ('bash', 'time { cat .agents/AGENTS.md; }', 'cat .agents/AGENTS.md', 'time_statement'),
 ('bash', 'time { rm -rf .agents; }', 'rm -rf .agents', 'time_statement'),
 ('bash', 'time cat .agents/AGENTS.md | cat', 'cat .agents/AGENTS.md', 'time_statement'),
 ('bash', 'time rm -rf .agents | cat', 'rm -rf .agents', 'time_statement'),
 ('zsh', 'foreach x (); cat .agents/AGENTS.md; end', 'cat .agents/AGENTS.md', 'foreach_statement'),
 ('zsh', 'foreach x (); rm -rf .agents; end', 'rm -rf .agents', 'foreach_statement'),
]
for lang, source, target, wrapper in cases:
    payload = source.encode('utf-8')
    syntax = subprocess.run(['/bin/' + lang, '-n'], input=payload, capture_output=True, timeout=5)
    assert syntax.returncode == 0, (lang, source, syntax.stderr)
    result = subprocess.run([binary, lang], input=payload, capture_output=True, timeout=5)
    assert result.returncode == 0, (lang, source, result.stderr)
    tree = json.loads(result.stdout.decode('utf-8'))
    assert tree['has_error'] is False, (lang, source, 'parse_error')
    def nodes(node):
        yield node
        for child in node['children']:
            yield from nodes(child)
    flat = list(nodes(tree))
    assert any(n['type'] == wrapper for n in flat), (lang, source, 'wrapper')
    assert any(n['type'] == 'command' and payload[n['start_byte']:n['end_byte']] == target.encode() for n in flat), (lang, source, 'target_span')
    print(lang, source, 'PASS')
print('six_case_ast_spans_GREEN',sys.version.split()[0])
